#  Copyright (c) 2026. RadonPy developers. All rights reserved.
#  Use of this source code is governed by a BSD-3-style
#  license that can be found in the LICENSE file.

# ******************************************************************************
# RadonPy __init__
# ******************************************************************************

__copyright__    = 'Copyright (C) 2026. RadonPy developers.'
__version__      = '1.0b2'
__license__      = 'BSD-3-Clause'
__author__       = 'Yoshihiro Hayashi'
__author_email__ = 'yhayashi@ism.ac.jp'
__url__          = 'https://github.com/RadonPy/RadonPy'

__all__ = [
    __copyright__,
    __version__,
    __license__,
    __author__,
    __author_email__,
    __url__
]
